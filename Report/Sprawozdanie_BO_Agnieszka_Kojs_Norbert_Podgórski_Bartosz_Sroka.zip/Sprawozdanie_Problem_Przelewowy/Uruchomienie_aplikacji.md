## Uruchomienie aplikacji
Ze względu na duży rozmiar aplikacji, przekraczający limit ustawiony na platformie Upel, 
proponujemy dwa rozwiązania uruchomienia aplikacji:

1) Pobrać z githuba (https://github.com/barteks019/-BO2-Bank-Transfers-Problem.git) 
archiwum: Sprawozdanie_BO_Agnieszka_Kojs_Norbert_Podgórski_Bartosz_Sroka.zip z folderu Report 
i uruchomić gui_PP.exe

2) Pobrać i rozpakować plik z platformy Upel. Następnie uruchomić konsolę w tym folderze 
naciskając prawy przycisk i wybierając "Windows Prompt" lub inną konsolę. Inny spsób na 
uruchomienie konsoli w konkretnym pliku to wpisanie w pasku adresu foldera "cmd". 
Następnie w wierszu poleceń (czyli konsoli) należy wpisać "python gui_PP.py". 